// App/index.js

import React, { Component } from "react";
class App extends Component {
  render() {
    return <div className="App">Hello World</div>;
  }
}

export default App;
